- [i] Status: 
- [i] Back links: 
___
# Theorie W1

## Scheme (R5Rs)
### Wiskundige Operaties
 \+ * + 1 2 3 sin 5 

 eerst 1 + 2 
 dan (1+2) * 3 
 dan 9 + sin 5

Atomaire: ondeelbaar (iets dat op zijn eigen bestaat zonder andere delen)
**Nesting**: expressions in andere expressions combineren.
     vb.:  (+ (* 2 3) 2 3)

atomaire expression: een getal 
combined expression: meerdere expressions (getallen), met als een of meerdere procedures
    vb.: (+ 1 2)
    ...    

 special form: een keyword 
     vb: (define)

Arrity: # vereiste parameters

### Procedure's
- gcd: greatest common devider
- lcd: least common devider
- modulo/remainder
- expt: macht
- log: logaritme
#### Booleans
\#t = true
\#f = false





 
# References
- 